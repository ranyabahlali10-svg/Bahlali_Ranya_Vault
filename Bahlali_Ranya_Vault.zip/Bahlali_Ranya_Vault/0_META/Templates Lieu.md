---
type_lieu: 
controle_par: 
premiere_apparition: 
---

# {{title}}

## Description du lieu


## Scènes clés
- 

## Personnages associés
- [[Nom]]