---
saison: 
affiliation: 
statut: 
importance: 
---

#  {{title}}

> [!abstract] Résumé rapide
> [Décrire ici en une phrase le rôle global du personnage]

---

## APPARENCE & PERSONNALITÉ
* **Traits physiques :** * **Caractère :** ### ARCS NARRATIFS
* **Saison X :** * **Saison Y :** ###  COMPÉTENCES & RÔLE DANS LE "JEU"
* **Alliés :** [[Lien]]
* **Ennemis :** [[Lien]]

---
# 📊 ANALYSE DATAVIEW LOCALE
```dataview
LIST FROM [[tables_perso]] WHERE contains(this.file.outlinks, file.link)
