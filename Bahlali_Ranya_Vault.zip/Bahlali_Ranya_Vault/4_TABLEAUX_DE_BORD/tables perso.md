# 📊 Table des Personnages

```dataview
TABLE saison, affiliation, statut, importance
FROM "1_PERSONNAGES"
WHERE saison
```
