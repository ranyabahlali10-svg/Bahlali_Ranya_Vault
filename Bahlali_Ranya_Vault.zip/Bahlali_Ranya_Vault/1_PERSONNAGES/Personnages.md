# Personnages de The Wire

## **POLICE & JUSTICE**

### Brigade des Stups

- [[Jimmy McNulty]] - Détective homicide, anti-héros
    
- [[Cedric Daniels]] - Lieutenant puis Commandant
    
- [[Kima Greggs]] - Détective sous couverture
    
- [[Bunk Moreland]] - Détective homicide
    
- [[Lester Freamon]] - Détective vétéran
    

### Police en Uniforme

- [[Ellis Carver]] - Officier de patrouille
    
- [[Thomas Hauk]] - Officier "Herc"
    
- [[Bunny Colvin]] - Commandant de district
    

### Hiérarchie

- [[William Rawls]] - Chef des homicides
    
- [[Ervin Burrell]] - Commissaire
    

##  **SYSTÈME CRIMINEL**

### Gang Barksdale

- [[Avon Barksdale]] - Chef suprême
    
- [[Stringer Bell]] - Stratège financier
    
- [[Wee-Bey Brice]] - Tueur à gages
    
- [[D'Angelo Barksdale]] - Neveu d'Avon
    
- [[Bodie Broadus]] - Soldat de rue
    


### Gang Stanfield

- [[Marlo Stanfield]] - Nouveau chef impitoyable
    
- [[Chris Partlow]] - Bras droit et tueur
    
- [[Snoop]] - Tueuse et recruteuse
    

### Indépendant

- [[Omar Little]] - Braqueur de dealers avec code moral
    
- [[Brother Mouzone]] - Tueur à gages professionnel
    
- [[Prop Joe]] - Négociant et pacificateur
    
- [[The Greek]] -Le fournisseur
    
##  **POLITIQUE & ADMINISTRATION**

### Municipalité

- [[Tommy Carcetti]] - Conseiller puis Maire
    
- [[Clarence Royce]] - Maire en poste
    
- [[Nerese Campbell]] - Conseillère municipale
    

### Système Judiciaire

- [[Rhonda Pearlman]] - Procureure
    
- [[Daniel Phelan]] - Juge
    

##  **SYNDICATS & PORT**

### Dockers

- [[Frank Sobotka]] - Secrétaire syndical
    
- [[Nick Sobotka]] - Neveu de Frank
    
- [[Ziggy Sobotka]] - Fils de Frank
    

##  **ÉDUCATION**

### Système Scolaire

- [[Howard Bunny Colvin]] - Principal
    
- [[Roland Prez Pryzbylewski]] - Professeur
    

##  **MÉDIAS**

### Baltimore Sun

- [[Gus Haynes]] - Rédacteur en chef
    
- [[Scott Templeton]] - Journaliste ambitieux
    
- [[Alma Gutierrez]] - Reporter