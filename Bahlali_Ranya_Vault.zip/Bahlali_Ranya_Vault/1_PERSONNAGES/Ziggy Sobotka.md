---
saison: "2"
affiliation: "Syndicat"
statut: "Emprisonné"
importance: "Secondaire"
---
**Affiliation:** Syndicat dockers  
**Rôle:** Docker  
**Saisons:** 2  
**Importance:** Secondaire

## Description
Fils inadapté cherchant la reconnaissance de son père.

## Arcs Narratifs
- Comportement erratique et provocateur
- Meurtre d'un trafiquant
- Emprisonnement

## Relations
- **Père:** [[Frank Sobotka]]
- **Cousin:** [[Nick Sobotka]]