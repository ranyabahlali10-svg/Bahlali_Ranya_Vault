---
saison: "5"
affiliation: "Médias"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Baltimore Sun  
**Rôle:** Reporter  
**Saisons:** 5  
**Importance:** Secondaire

## Description
Elle représente ce que le journalisme devrait être, face au déclin du Baltimore Sun qui cherche des prix (le Pulitzer) plutôt que la précision. Elle finit par être la victime du système, rétrogradée alors qu'elle était la seule à avoir raison.

## Arcs Narratifs
- Enquête sur la situation des sans-abri
- Découverte des mensonges de Templeton
- Difficultés professionnelles

## Relations
- **Supérieur:** [[Gus Haynes]]
- **Collègue:** [[Scott Templeton]]