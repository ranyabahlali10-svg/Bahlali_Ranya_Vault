---
saison: "3-5"
affiliation: "Politique"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Politique  
**Rôle:** Conseillère municipale  
**Saisons:** 3-5  
**Importance:** Secondaire

## Description
Femme très opportuniste dans la politique.

## Arcs Narratifs
- Soutien à Royce puis retournement
- Manœuvres politiques au conseil municipal
- Ambitions personnelles

## Relations
- **Allié:** [[Clarence Royce]]
- **Rival:** [[Tommy Carcetti]]