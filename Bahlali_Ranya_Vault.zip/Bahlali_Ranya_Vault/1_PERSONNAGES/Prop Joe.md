---
saison: "1-5"
affiliation: "Criminel"
statut: "Mort"
importance: "Secondaire"
---
**Affiliation:** Gang Est  
**Rôle:** Négociant  
**Saisons:** 1-5  
**Importance:** Secondaire

## Description
Pacificateur et homme d'affaires du crime, préfère la négociation à la violence.

## Arcs Narratifs
- Fourniture de drogue aux autres gangs
- Tentative d'alliance avec Stringer Bell
- Meurtre commandité par Marlo

## Relations
- Associé : [[Stringer Bell]]
- Contact : [[Marlo Stanfield]]