---
saison: "1-5"
affiliation: "Police"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Police  
**Rôle:** Officier "Herc"  
**Saisons:** 1-5  
**Importance:** Secondaire

## Description
Officier brutal mais loyal, souvent impulsif dans ses actions.

## Arcs Narratifs
- Patrouilles dans les rues de Baltimore
- Implication dans diverses affaires de drogue
- Passage en unité spéciale

## Relations
- Partenaire : [[Ellis Carver]]
- Supérieurs : [[Cedric Daniels]], [[Bunny Colvin]]