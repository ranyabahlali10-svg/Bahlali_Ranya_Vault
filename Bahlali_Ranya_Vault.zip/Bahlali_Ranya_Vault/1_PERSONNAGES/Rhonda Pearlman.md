---
saison: "1-5"
affiliation: "Justice"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Justice  
**Rôle:** Procureure  
**Saisons:** 1-5  
**Importance:** Secondaire

## Description
Procureure ambitieuse qui est placé entre justice et politique.

## Arcs Narratifs
- Poursuites contre les gangs Barksdale et Stanfield
- Mariage avec Cedric Daniels
- Ascension dans la hiérarchie judiciaire

## Relations
- **Époux:** [[Cedric Daniels]]
- **Ex-amant:** [[Jimmy McNulty]]
- **Collègue:** [[Daniel Phelan]]