---
saison: "1-5"
affiliation: "Criminel"
statut: "Mort"
importance: "Principale"
---
**Affiliation:** Indépendant  
**Rôle:** Braqueur de dealers  
**Saisons:** 1-5  
**Importance:** Principale

## Description
Hors-la-loi avec code moral, légende des rues, ne cible que les trafiquants.

## Arcs Narratifs
- Braquages successifs des gangs Barksdale et Stanfield
- Vengeance pour la mort de son amant
- Mort tragique dans une épicerie

## Relations
- Rivaux : [[Avon Barksdale]], [[Stringer Bell]], [[Marlo Stanfield]]
- Allié temporaire : [[Brother Mouzone]]
- Contact police : [[Bunk Moreland]]