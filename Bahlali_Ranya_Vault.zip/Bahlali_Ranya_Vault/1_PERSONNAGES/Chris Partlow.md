---
saison: "3-5"
affiliation: "Criminel"
statut: "Emprisonné"
importance: "Secondaire"
---
**Affiliation:** Gang Stanfield  
**Rôle:** Bras droit et tueur  
**Saisons:** 3-5  
**Importance:** Secondaire

## Description
Tueur efficace et discipliné, totalement dévoué à Marlo.

## Arcs Narratifs
- Exécution des ordres de Marlo
- Gestion des meurtres et intimidations
- Emprisonnement à la fin

## Relations
- **Patron:** [[Marlo Stanfield]]
- **Collègue:** [[Snoop]]