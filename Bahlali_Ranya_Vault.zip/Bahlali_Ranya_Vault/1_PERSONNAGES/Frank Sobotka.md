---
saison: "2"
affiliation: "Syndicat"
statut: "Mort"
importance: "Secondaire"
---
<div style="background-color: #1a1a1a; border-left: 6px solid #f26522; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
    <span style="color: #f26522; font-weight: bold; text-transform: uppercase; font-size: 0.8em;">DOCKS - LOCAL 47</span>
    <h2 style="margin: 5px 0; color: white;">Frank Sobotka</h2>
    <p style="color: #888; font-size: 0.9em; margin: 0;">Enquête sur la contrebande portuaire (Saison 2).</p>
</div>
**Affiliation:** Syndicat dockers  
**Rôle:** Secrétaire syndical  
**Saisons:** 2  
**Importance:** Principale

## Description
Syndicaliste corrompu pour sauver les docks et les emplois.

## Arcs Narratifs
- Contrebande via le port de Baltimore
- Lutte pour la survie des docks
- Meurtre commandité

## Relations
- **Neveu:** [[Nick Sobotka]]
- **Fils:** [[Ziggy Sobotka]]
- **Contact:** [[The Greek]]