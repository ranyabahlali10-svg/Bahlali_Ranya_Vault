---
saison: "1-5"
affiliation: "Police"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Police  
**Rôle:** Officier → Sergent  
**Saisons:** 1-5  
**Importance:** Secondaire

## Description
Officier qui évolue de la corruption vers la gradation dans la police.

## Arcs Narratifs
- Patrouille dans les quartiers chauds avec Herc
- Promotion au rang de sergent
- Prise de responsabilités dans le district

## Relations
- Partenaire : [[Thomas Hauk]]
- Supérieurs : [[Cedric Daniels]], [[Bunny Colvin]]
- Collègue : [[Kima Greggs]]