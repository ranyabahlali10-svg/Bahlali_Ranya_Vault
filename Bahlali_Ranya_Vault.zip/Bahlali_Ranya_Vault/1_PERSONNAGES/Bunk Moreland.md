---
saison: "1-5"
affiliation: "Police"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Police  
**Rôle:** Détective homicide  
**Saisons:** 1-5  
**Importance:** Secondaire

## Description
Détective traditionnel, méthodique, partenaire loyal de McNulty.

## Arcs Narratifs
- Partenaire de McNulty sur les enquêtes homicides
- Enquête sur les meurtres liés au trafic de drogue
- Témoin de la descente aux enfers de Jimmy

## Relations
- Partenaire : [[Jimmy McNulty]]
- Mentor pour : [[Kima Greggs]]
- Supérieur : [[William Rawls]]
- Collègues : [[Lester Freamon]]
- Contact : [[Omar Little]]