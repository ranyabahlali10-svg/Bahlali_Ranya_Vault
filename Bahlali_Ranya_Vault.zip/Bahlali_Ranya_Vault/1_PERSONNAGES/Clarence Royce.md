---
saison: "3-4"
affiliation: "Politique"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Politique  
**Rôle:** Maire en poste  
**Saisons:** 3-4  
**Importance:** Secondaire

## Description
Maire corrompu qui cherche a diffamer pour réussir.

## Arcs Narratifs
- Campagne électorale contre Carcetti
- Gestion politicienne de la ville
- Défaite aux élections

## Relations
- **Rival:** [[Tommy Carcetti]]
- **Alliée:** [[Nerese Campbell]]