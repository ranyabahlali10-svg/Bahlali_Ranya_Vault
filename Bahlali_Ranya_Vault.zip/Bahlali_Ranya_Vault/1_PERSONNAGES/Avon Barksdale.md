---
saison: "1-3"
affiliation: "Criminel"
statut: "Emprisonné"
importance: "Principale"
---
<div style="background-color: #1a1a1a; border-left: 6px solid #f26522; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
    <span style="color: #f26522; font-weight: bold; text-transform: uppercase; font-size: 0.8em;">STREET - CLAN BARKSDALE</span>
    <h2 style="margin: 5px 0; color: white;">Avon Barksdale</h2>
    <p style="color: #888; font-size: 0.9em; margin: 0;">Leader identifié de l'organisation criminelle de l'Ouest.</p>
</div>
**Affiliation:** Gang Barksdale  
**Rôle:** Chef suprême  
**Saisons:** 1-3  
**Importance:** Principale

## Description
Patron du gang impitoyable mais attaché à ses racines et codes de la rue.

## Arcs Narratifs
- Contrôle du trafic de drogue à l'Ouest de Baltimore
- Conflit avec Marlo Stanfield pour le territoire
- Emprisonnement et perte de pouvoir

## Relations
- Lieutenant : [[Stringer Bell]]
- Neveu : [[D'Angelo Barksdale]]
- Soldats : [[Wee-Bey Brice]], [[Bodie Broadus]]
- Rivaux : [[Marlo Stanfield]], [[Omar Little]]
- Enquête sur lui : [[Brother Mouzone]]