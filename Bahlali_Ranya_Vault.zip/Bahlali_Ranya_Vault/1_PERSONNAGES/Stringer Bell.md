---
saison: "1-3"
affiliation: "Criminel"
statut: "Mort"
importance: "Principale"
---
**Affiliation:** Gang Barksdale  
**Rôle:** Stratège financier  
**Saisons:** 1-3  
**Importance:** Principale

## Description
Cerveau du gang, veut légitimer les affaires et moderniser le crime, veut utiliser l'argent de la rue pour monter d'autre business légal.

## Arcs Narratifs
- Tentative de blanchiment d'argent
- Investissement dans l'immobilier légal
- Conflit avec Avon sur la direction du gang

## Relations
- Patron : [[Avon Barksdale]]
- Associé : [[Avon Barksdale]]
- Contact : [[Prop Joe]]
- Rivaux : [[Marlo Stanfield]], [[Omar Little]]
- Enquête sur lui : [[Lester Freamon]], [[Brother Mouzone]]