---
saison: "3-5"
affiliation: "Criminel"
statut: "Actif"
importance: "Principale"
---
<div style="background-color: #1a1a1a; border-left: 6px solid #f26522; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
    <span style="color: #f26522; font-weight: bold; text-transform: uppercase; font-size: 0.8em;">STREET - CLAN STANFIELD</span>
    <h2 style="margin: 5px 0; color: white;">Marlo Stanfield</h2>
    <p style="color: #888; font-size: 0.9em; margin: 0;">Menace majeure en expansion. Dangerosité extrême.</p>
</div>
**Affiliation:** Gang Stanfield  
**Rôle:** Chef  
**Saisons:** 3-5  
**Importance:** Principale

## Description
Successeur impitoyable d'Avon, qui cherche le respect et de pouvoir.

## Arcs Narratifs
- Prise de contrôle des territoires Barksdale
- Guerre de territoire sanglante
- Blanchiment d'argent et tentative de légitimation

## Relations
- Lieutenants : [[Chris Partlow]], [[Snoop]]
- Soldat : [[Bodie Broadus]]
- Rivaux : [[Avon Barksdale]], [[Omar Little]]
- Fournisseur : [[The Greek]]
- Contact : [[Prop Joe]]