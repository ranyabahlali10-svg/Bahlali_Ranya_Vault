---
saison: "1-5"
affiliation: "Police"
statut: "Actif"
importance: "Principale"
---
**Affiliation:** Police  
**Rôle:** Détective sous couverture  
**Saisons:** 1-5  
**Importance:** Principale

## Description
Détective talentueuse, l'une des rares femmes en première ligne.

## Arcs Narratifs
- Blessure en mission (S1)
- Passage aux homicides
- Vie familiale

## Relations
- Partenaire : [[Ellis Carver]]
- Mentor : [[Bunk Moreland]]
- Supérieur : [[Cedric Daniels]]
- Collègues : [[Jimmy McNulty]], [[Lester Freamon]]