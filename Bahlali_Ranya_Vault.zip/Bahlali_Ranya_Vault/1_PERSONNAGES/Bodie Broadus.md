---
saison: "1-4"
affiliation: "Criminel"
statut: "Mort"
importance: "Secondaire"
---
**Affiliation:** Gang Barksdale → Stanfield  
**Rôle:** Soldat de rue  
**Saisons:** 1-4  
**Importance:** Secondaire

## Description
Soldat loyal qui évolue sur 4 saisons, représentant de la "vieille école".

## Arcs Narratifs
- Ascension dans la hiérarchie du gang
- Passage chez Stanfield après la chute de Barksdale
- Mort en défendant son territoire

## Relations
- **Patron:** [[Avon Barksdale]] → [[Marlo Stanfield]]