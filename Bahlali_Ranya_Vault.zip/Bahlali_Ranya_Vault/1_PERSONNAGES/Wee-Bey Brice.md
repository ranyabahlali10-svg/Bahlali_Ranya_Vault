---
saison: "1-5"
affiliation: "Criminel"
statut: "Emprisonné"
importance: "Secondaire"
---
**Affiliation:** Gang Barksdale  
**Rôle:** Tueur à gages  
**Saisons:** 1-5  
**Importance:** Secondaire

## Description
Soldat loyal et impitoyable, exécuteur des basses œuvres du gang.

## Arcs Narratifs
- Exécution de multiples meurtres pour le gang
- Emprisonnement et aveux pour protéger Avon
- Père en prison

## Relations
- **Patron:** [[Avon Barksdale]]
- **Collègue:** [[Stringer Bell]]