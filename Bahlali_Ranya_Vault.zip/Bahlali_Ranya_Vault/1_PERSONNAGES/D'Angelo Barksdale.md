---
saison: "1-2"
affiliation: "Criminel"
statut: "Mort"
importance: "Secondaire"
---
**Affiliation:** Gang Barksdale  
**Rôle:** Lieutenant  
**Saisons:** 1-2  
**Importance:** Secondaire

## Description
Neveu d'Avon en crise de conscience, coincé entre famille et moralité.

## Arcs Narratifs
- Gestion des corners de drogue
- Découragement face à la violence du milieu
- Collaboration avec la police avant son meurtre

## Relations
- **Oncle:** [[Avon Barksdale]]
- **Mentor:** [[Stringer Bell]]