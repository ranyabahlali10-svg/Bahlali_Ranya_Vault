---
saison: "1-5"
affiliation: "Police"
statut: "Retraité"
importance: "Principale"
---
**Affiliation:** Police  
**Statut:** Lieutenant puis Commandant  
**Saisons:** 1-5  
**Importance:** Principale

## Description
Commandant ambitieux mais intègre, doit naviguer entre politique et travail de terrain.

## Arcs Narratifs
- Direction de l'unité Barksdale (S1-3)
- Ascension hiérarchique (S4-5)
- Relation avec [[Rhonda Pearlman]]

## Relations
- Épouse : [[Rhonda Pearlman]]
- Subordonnés : [[Jimmy McNulty]], [[Kima Greggs]], [[Lester Freamon]], [[Ellis Carver]], [[Thomas Hauk]]
- Collègues : [[William Rawls]]
- Contact politique : [[Tommy Carcetti]]