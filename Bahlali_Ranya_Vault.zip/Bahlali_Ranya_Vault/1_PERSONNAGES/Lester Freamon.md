---
saison: "1-5"
affiliation: "Police"
statut: "Retraité"
importance: "Secondaire"
---
**Affiliation:** Police  
**Rôle:** Détective vétéran  
**Saisons:** 1-5  
**Importance:** Secondaire

## Description
Détective patient et méthodique, expert en filatures et écoutes.

## Arcs Narratifs
- Découverte du réseau Barksdale via les factures
- Direction des investigations financières
- Enquête sur les meurtres commandités

## Relations
- Supérieur : [[Cedric Daniels]]
- Collègues : [[Jimmy McNulty]], [[Bunk Moreland]], [[Kima Greggs]]
- Enquête sur : [[Stringer Bell]]