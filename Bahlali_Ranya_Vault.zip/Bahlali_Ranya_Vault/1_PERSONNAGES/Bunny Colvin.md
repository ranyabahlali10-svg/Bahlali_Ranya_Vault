---
saison: "3-4"
affiliation: "Police"
statut: "Retraité"
importance: "Secondaire"
---
**Affiliation:** Police → Éducation  
**Rôle:** Commandant → Principal  
**Saisons:** 3-4  
**Importance:** Secondaire

## Description
Commandant innovant qui crée les zones franches, puis devient éducateur.

## Arcs Narratifs
- Création des zones de tolérance pour la drogue
- Renvoi de la police après le scandale
- Reconversion dans l'éducation

## Relations
- **Subordonné:** [[Ellis Carver]]
- **Subordonné:** [[Thomas Hauk]]