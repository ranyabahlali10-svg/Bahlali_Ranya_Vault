---
saison: "1-4"
affiliation: "Éducation"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Police → Éducation  
**Rôle:** Officier → Professeur  
**Saisons:** 1-4  
**Importance:** Secondaire

## Description
Policier inadapté devenant un excellent professeur dévoué.

## Arcs Narratifs
- Carrière policière ratée avec plusieurs bavures
- Reconversion dans l'enseignement
- Succès comme éducateur

## Relations
- **Ancien collègue:** [[Ellis Carver]]
- **Ancien collègue:** [[Thomas Hauk]]
- **Collègue:** [[Howard Colvin]]