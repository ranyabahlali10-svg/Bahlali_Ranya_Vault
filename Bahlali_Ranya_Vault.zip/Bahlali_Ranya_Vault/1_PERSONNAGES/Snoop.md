---
saison: "3-5"
affiliation: "Criminel"
statut: "Mort"
importance: "Secondaire"
---
**Affiliation:** Gang Stanfield  
**Rôle:** Tueuse et recruteuse  
**Saisons:** 3-5  
**Importance:** Secondaire

## Description
Tueuse impitoyable et loyale, recruteuse de jeunes dealers.

## Arcs Narratifs
- Recrutement et formation des jeunes soldats
- Participation aux meurtres commandités
- Mort lors d'une confrontation

## Relations
- **Patron:** [[Marlo Stanfield]]
- **Collègue:** [[Chris Partlow]]