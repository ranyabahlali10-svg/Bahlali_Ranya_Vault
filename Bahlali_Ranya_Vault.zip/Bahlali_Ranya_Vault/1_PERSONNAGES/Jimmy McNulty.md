---
saison: 1-5
affiliation: Police
statut: Actif
importance: Principale
---
<div style="background-color: #1a1a1a; border-left: 6px solid #f26522; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
    <span style="color: #f26522; font-weight: bold; text-transform: uppercase; font-size: 0.8em;">BPD - UNITÉ SPÉCIALE</span>
    <h2 style="margin: 5px 0; color: white;">Jimmy McNulty</h2>
    <p style="color: #888; font-size: 0.9em; margin: 0;">Cible des enquêtes disciplinaires</p>
</div>
**Affiliation:** Police  
**Statut:** Détective homicide  
**Saisons:** 1-5  
**Importance:** Principale

## Description
Détective brillant mais auto-destructeur, alcoolique, en conflit permanent avec la hiérarchie.

## Arcs Narratifs
- Enquête sur le gang Barksdale (S1)
- Création de l'unité des meurtres (S3)
- Enquête sur les dockers (S2)
- Affaire Stanfield (S4-5)

## Relations
- Partenaire : [[Bunk Moreland]]
- Supérieur : [[Cedric Daniels]]
- Rival : [[William Rawls]]
- Ex-relation : [[Rhonda Pearlman]]
- Collègues : [[Kima Greggs]], [[Lester Freamon]]
- Contact judiciaire : [[Daniel Phelan]]

## Citations Mémorables
> "What the fuck did I do?"

## Tags
#personnage-principal #police #détective #saison1-5