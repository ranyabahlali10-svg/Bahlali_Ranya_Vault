---
saison: "3-4"
affiliation: "Police"
statut: "Retraité"
importance: "Secondaire"
---
**Affiliation:** Police  
**Rôle:** Chef des homicides  
**Saisons:** 1-5  
**Importance:** Secondaire

## Description
Chef bureaucratique et ambitieux, souvent en conflit avec McNulty.

## Arcs Narratifs
- Gestion de l'unité des homicides
- Conflits permanents avec McNulty
- Ascension dans la hiérarchie policière

## Relations
- **Subordonné:** [[Jimmy McNulty]]
- **Rival:** [[Jimmy McNulty]]
- **Collègue:** [[Cedric Daniels]]