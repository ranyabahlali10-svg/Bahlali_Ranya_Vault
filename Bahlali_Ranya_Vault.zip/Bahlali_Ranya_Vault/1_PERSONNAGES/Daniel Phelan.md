---
saison: "1-2"
affiliation: "Justice"
statut: "Retraité"
importance: "Secondaire"
---
**Affiliation:** Justice  
**Rôle:** Juge  
**Saisons:** 1-2  
**Importance:** Secondaire

## Description
Juge soutenant les enquêtes policières.

## Arcs Narratifs
- Délivrance des mandats pour l'unité Barksdale
- Soutien aux méthodes de surveillance
- Retraite de la magistrature

## Relations
- Collaborateurs judiciaires : [[Cedric Daniels]], [[Jimmy McNulty]]
- Collègue judiciaire : [[Rhonda Pearlman]]