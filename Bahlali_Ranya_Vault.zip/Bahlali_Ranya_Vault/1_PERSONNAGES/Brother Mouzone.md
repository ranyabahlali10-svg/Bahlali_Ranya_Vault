---
saison: "2-3"
affiliation: "Criminel"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Indépendant  
**Rôle:** Tueur à gages pro  
**Saisons:** 2-3  
**Importance:** Secondaire

## Description
Tueur professionnel et élégant, venant de New York.

## Arcs Narratifs
- Enquête sur le meurtre de son associé
- Alliance improbable avec Omar
- Règlement de comptes avec Stringer Bell

## Relations
- Allié temporaire : [[Omar Little]]
- Cible : [[Stringer Bell]]
- Enquête sur : [[Avon Barksdale]]