---
saison: "5"
affiliation: "Médias"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Baltimore Sun  
**Rôle:** Journaliste  
**Saisons:** 5  
**Importance:** Secondaire

## Description
Journaliste ambitieux et malhonnête, prêt à tout pour réussir.

## Arcs Narratifs
- Fabrication de sources et d'interviews
- Obtention du prix Pulitzer par fraude
- Conflit avec la rédaction

## Relations
- **Supérieur:** [[Gus Haynes]]
- **Collègue:** [[Alma Gutierrez]]