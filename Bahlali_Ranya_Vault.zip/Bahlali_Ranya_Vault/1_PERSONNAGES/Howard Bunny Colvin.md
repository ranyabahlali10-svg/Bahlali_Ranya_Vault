---
saison: "4"
affiliation: "Éducation"
statut: "Retraité"
importance: "Secondaire"
---
**Affiliation:** Éducation  
**Rôle:** Principal  
**Saisons:** 4  
**Importance:** Secondaire

## Description
Ancien commandant devenu éducateur innovant et engagé.

## Arcs Narratifs
- Programme éducatif expérimental avec les élèves difficiles
- Lutte contre le système scolaire traditionnel
- Impact sur les jeunes en difficulté

## Relations
- **Ancien subordonné:** [[Ellis Carver]]
- **Ancien subordonné:** [[Thomas Hauk]]
- **Collègue:** [[Roland Prez Pryzbylewski]]