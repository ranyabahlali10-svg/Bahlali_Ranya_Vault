---
saison: "2,5"
affiliation: "Criminel"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Crime organisé  
**Rôle:** Parrain du crime international  
**Saisons:** 2, 5  
**Importance:** Secondaire

## Description
Parrain mystérieux et fournisseur, chef d'un réseau criminel international.

## Arcs Narratifs
- Contrôle du trafic de drogue et de la contrebande via le port
- Collaboration avec les dockers et Frank Sobotka
- Expansion de son empire criminel
- Survie et continuation de ses activités

## Relations
- Contacts : [[Frank Sobotka]], [[Nick Sobotka]]
- Client : [[Marlo Stanfield]]