---
saison: "5"
affiliation: "Médias"
statut: "Actif"
importance: "Secondaire"
---
<div style="background-color: #1a1a1a; border-left: 6px solid #f26522; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
    <span style="color: #f26522; font-weight: bold; text-transform: uppercase; font-size: 0.8em;">MÉDIAS - BALTIMORE SUN</span>
    <h2 style="margin: 5px 0; color: white;">Gus Haynes</h2>
    <p style="color: #888; font-size: 0.9em; margin: 0;">Un regard critique sur la crise et les dérives des médias.</p>
</div>
**Affiliation:** Baltimore Sun  
**Rôle:** Rédacteur en chef  
**Saisons:** 5  
**Importance:** Secondaire

## Description
Journaliste intègre dans un monde corrompu.

## Arcs Narratifs
- Supervision des enquêtes journalistiques
- Lutte contre les mensonges de Templeton
- Défense de l'intégrité journalistique

## Relations
- **Subordonné:** [[Scott Templeton]]
- **Subordonnée:** [[Alma Gutierrez]]