---
saison: "2"
affiliation: "Syndicat"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Syndicat dockers  
**Rôle:** Docker  
**Saisons:** 2  
**Importance:** Secondaire

## Description
Docker impliqué dans la contrebande pour survivre.

## Arcs Narratifs
- Implication dans le trafic de drogue
- Collaboration avec la police
- Nouvelle vie après les événements

## Relations
- Oncle : [[Frank Sobotka]]
- Contact : [[The Greek]]
- Cousin : [[Ziggy Sobotka]]