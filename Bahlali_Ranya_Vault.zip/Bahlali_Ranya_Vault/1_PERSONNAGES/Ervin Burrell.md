---
saison: "1-5"
affiliation: "Police"
statut: "Actif"
importance: "Secondaire"
---
**Affiliation:** Police  
**Rôle:** Commissaire  
**Saisons:** 1-5  
**Importance:** Secondaire

## Description
Commissaire politique, plus soucieux de son image que du travail de terrain.

## Arcs Narratifs
- Gestion politique du département de police
- Conflits avec le maire et les élus
- Remplacé par Daniels

## Relations
- **Subordonné:** [[Cedric Daniels]]
- **Subordonné:** [[William Rawls]]