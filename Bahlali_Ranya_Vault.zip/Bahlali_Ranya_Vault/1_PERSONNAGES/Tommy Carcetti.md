---
saison: "3-5"
affiliation: "Politique"
statut: "Actif"
importance: "Principale"
---
<div style="background-color: #1a1a1a; border-left: 6px solid #f26522; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
    <span style="color: #f26522; font-weight: bold; text-transform: uppercase; font-size: 0.8em;">CITY HALL - MAIRIE</span>
    <h2 style="margin: 5px 0; color: white;">Tommy Carcetti</h2>
    <p style="color: #888; font-size: 0.9em; margin: 0;">Suivi politique : Campagne électorale et réformes.</p>
</div>
**Affiliation:** Politique  
**Rôle:** Conseiller → Maire  
**Saisons:** 3-5  
**Importance:** Principale

## Description
Politique ambitieux, idéaliste devenu cynique au pouvoir.

## Arcs Narratifs
- Élection comme maire de Baltimore
- Lutte contre la criminalité et réformes
- Conflits avec le gouvernement de l'État

- Rival politique : [[Clarence Royce]]
- Collaborateur : [[Cedric Daniels]]
- Opposant : [[Nerese Campbell]]