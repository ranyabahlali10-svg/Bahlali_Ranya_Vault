---
type_lieu: Zone de trafic résidentielle
controle_par: Clan Barksdale
premiere_apparition: Saison 1
---

# The Pit (Les Tours)

## Description du lieu
Zone de deal située au cœur des projets immobiliers de l'Ouest de Baltimore. C'est un espace clos qui sert de centre de profit pour l'organisation Barksdale et de lieu de vie pour les "pions" du système.

## Scènes clés
- La scène du jeu d'échecs avec D'Angelo.
- Les descentes régulières de la police pour marquer le territoire.

## Personnages associés
- [[D'Angelo Barksdale]]
- [[Bodie Broadus]]