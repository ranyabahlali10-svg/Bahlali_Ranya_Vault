---
type_lieu: Institution Publique
controle_par: Commissaire de Police / Mairie
premiere_apparition: Saison 1
---

# Le BPD (Baltimore Police Department)

## Description du lieu
Le quartier général de la police est le point névralgique où se croisent les enquêtes de terrain et les pressions politiques. C'est ici que s'illustre la faillite institutionnelle par la manipulation des statistiques de criminalité.

##  Scènes clés
- La création de l'unité spéciale dans les sous-sols (Saison 1).
- Les réunions "ComStat" où les majors sont mis sous pression pour les chiffres.

## Personnages associés
- [[Jimmy McNulty]]
- [[Cedric Daniels]]
- [[Bunk Moreland]]