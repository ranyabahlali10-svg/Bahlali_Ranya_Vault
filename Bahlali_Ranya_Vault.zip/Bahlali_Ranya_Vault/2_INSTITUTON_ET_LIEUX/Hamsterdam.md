---
type_lieu: Zone de tolérance (Free Zone)
controle_par: Major Bunny Colvin
premiere_apparition: Saison 3
---

# Hamsterdam

## Description du lieu
Une zone abandonnée où la drogue est tolérée pour pacifier les quartiers résidentiels. Ce lieu illustre une tentative désespérée de changer les règles du "Jeu" institutionnel.

## Scènes clés
- La découverte de la zone par les policiers de terrain.
- Le démantèlement final ordonné par la mairie.

## Personnages associés
- [[Bunny Colvin]]
- [[The Deacon]]