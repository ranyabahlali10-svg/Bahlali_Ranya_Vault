---
type_lieu: Centre Administratif
controle_par: Le Maire
premiere_apparition: Saison 1
---

# City Hall (La Mairie)

## Description du lieu
Le centre de décision politique de Baltimore. Dans le Canvas, ce lieu est situé au sommet de la pyramide car les décisions budgétaires qui y sont prises impactent directement la réalité du terrain et de la police.

## Scènes clés
- Les débats budgétaires sur l'école vs la police.
- L'ascension politique de Tommy Carcetti.

## Personnages associés
- [[Tommy Carcetti]]
- [[Clarence Royce]]